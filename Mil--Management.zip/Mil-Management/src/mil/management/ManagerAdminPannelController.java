/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.management;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author User
 */
public class ManagerAdminPannelController implements Initializable {
    //variable declearation
    Statement statement;
    @FXML
    private TextField memberNameField;
    @FXML
    private TextField memberPhoneField;
    @FXML
    private TextField memberEmailField;
    @FXML
    private TextField memberJobField;
    @FXML
    private TextField memberAddressField;
    @FXML
    private TextField memberOtherField;
    @FXML
    private TableView<Member> memberTableView;
    private ObservableList<Member> memberTableViewObserb;
    @FXML
    private TableColumn<Member, Number> memberNoColumn;
    @FXML
    private TableColumn<Member, String> memberNameColumn;
    @FXML
    private TableColumn<Member, String> memberPhoneColumn;
    @FXML
    private TableColumn<Member, String> memberEmailColumn;
    @FXML
    private TableColumn<Member, String> memberJobColumn;
    @FXML
    private TableColumn<Member, String> memberAddressColumn;
    @FXML
    private TableColumn<Member, String> memberOtherColumn;
    @FXML
    private Label addupdelSuccessLable;
    @FXML
    private ComboBox<String> memberBazarComboBox;
    private ObservableList<String> memberBazarComboBoxObserve;
    @FXML
    private TextField bazarAmountField;
    @FXML
    private TextArea bazarMenuField;
    @FXML
    private Label bazarAddSuccessLabel;
    @FXML
    private TableView<Bazar> bazarTableView;
    private ObservableList<Bazar> bazarTableViewObserv;
    @FXML
    private TableColumn<Bazar, String> bazarDateColumn;
    @FXML
    private TableColumn<Bazar, Number> bazarNoColumn;
    @FXML
    private TableColumn<Bazar, String> bazarNameColumn;
    @FXML
    private TableColumn<Bazar, Number> bazarAmountColumn;
    @FXML
    private TableColumn<Bazar, String> bazarMenuColumn;
    @FXML
    private ComboBox<String> memberExtraBazarComboBox;
    private ObservableList<String> memberExtraBazarComboBoxObserve;
    @FXML
    private TextField extraBazarAmountField;
    @FXML
    private TextArea extraBazarMenuField;
    @FXML
    private TableView<ExtraBazar> extraBazarTableView;
    private ObservableList<ExtraBazar> extraBazarTableViewObserv;
    @FXML
    private TableColumn<ExtraBazar, Number> extrabazarNoColumn;
    @FXML
    private TableColumn<ExtraBazar, String> extrabazarDateColumn;
    @FXML
    private TableColumn<ExtraBazar, String> extrabazarNameColumn;
    @FXML
    private TableColumn<ExtraBazar, Number> extrabazarAmountColumn;
    @FXML
    private TableColumn<ExtraBazar, String> extrabazarMenuColumn;
    @FXML
    private TableView<Depositor> moneyDepositTableView;
    private ObservableList<Depositor> moneyDepositTableViewObserv;
    @FXML
    private TableColumn<Depositor, String> moneyDepositNameColumn;
    @FXML
    private TableColumn<Depositor, Number> moneyDepositAmountColumn;
    @FXML
    private TableColumn<Depositor, String> moneyDepositDateColumn;
    @FXML
    private ComboBox<String> moneyDepositorComboBox;
    private ObservableList<String> moneyDepositorComboBoxObserve;
    @FXML
    private TableColumn<Depositor, Number> moneyDepositNoColumn;
    @FXML
    private TextField moneyDepositAmountField;
    @FXML
    private Label addMoneySuccessLable;
    @FXML
    private DatePicker datePicker;
    @FXML
    private Label extrabazarAddSuccessLabel;
    @FXML
    private DatePicker mainBazardatePicker;
    @FXML
    private DatePicker extraBazardatePicker;
    @FXML
    private TableView<MealChart> mealChartTableView;
    private ObservableList<MealChart> mealChartTableViewObserv;
    @FXML
    private TableColumn<MealChart, String> mealarNameColumn;
    @FXML
    private TableColumn<MealChart, Number> mealDay1;
    @FXML
    private TableColumn<MealChart, Number> mealDay2;
    @FXML
    private TableColumn<MealChart, Number> mealDay3;
    @FXML
    private TableColumn<MealChart, Number> mealDay4;
    @FXML
    private TableColumn<MealChart, Number> mealDay5;
    @FXML
    private TableColumn<MealChart, Number> mealDay6;
    @FXML
    private TableColumn<MealChart, Number> mealDay7;
    @FXML
    private TableColumn<MealChart, Number> mealDay8;
    @FXML
    private TableColumn<MealChart, Number> mealDay9;
    @FXML
    private TableColumn<MealChart, Number> mealDay10;
    @FXML
    private TableColumn<MealChart, Number> mealDay11;
    @FXML
    private TableColumn<MealChart, Number> mealDay12;
    @FXML
    private TableColumn<MealChart, Number> mealDay13;
    @FXML
    private TableColumn<MealChart, Number> mealDay14;
    @FXML
    private TableColumn<MealChart, Number> mealDay15;
    @FXML
    private TableColumn<MealChart, Number> mealDay16;
    @FXML
    private TableColumn<MealChart, Number> mealDay17;
    @FXML
    private TableColumn<MealChart, Number> mealDay18;
    @FXML
    private TableColumn<MealChart, Number> mealDay19;
    @FXML
    private TableColumn<MealChart, Number> mealDay20;
    @FXML
    private TableColumn<MealChart, Number> mealDay21;
    @FXML
    private TableColumn<MealChart, Number> mealDay22;
    @FXML
    private TableColumn<MealChart, Number> mealDay23;
    @FXML
    private TableColumn<MealChart, Number> mealDay24;
    @FXML
    private TableColumn<MealChart, Number> mealDay25;
    @FXML
    private TableColumn<MealChart, Number> mealDay26;
    @FXML
    private TableColumn<MealChart, Number> mealDay27;
    @FXML
    private TableColumn<MealChart, Number> mealDay28;
    @FXML
    private TableColumn<MealChart, Number> mealDay29;
    @FXML
    private TableColumn<MealChart, Number> mealDay30;
    @FXML
    private TableColumn<MealChart, Number> mealDay31;
    @FXML
    private ComboBox<String> mealarRegComboBox;
    private ObservableList<String> mealarRegComboBoxObserve;
    @FXML
    private TextField mealAmountField;
    @FXML
    private ComboBox<Number> mealDayComboBox;
    private ObservableList<Number> mealDayComboBoxObserve;
    @FXML
    private Label addMealSuccessLable;
    @FXML
    private Label settingsSuccessLable;

    /**
     * Initialises the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        LocalDate today = LocalDate.now();
        datePicker.setValue(today);
        mainBazardatePicker.setValue(today);
        extraBazardatePicker.setValue(today);
        //extraBazardatePicker.setValue(today);
        try {
            String DB_URL = "jdbc:mysql://localhost/meal_management_db";
            String DB_USER = "root";
            String DB_PASS = "mysqlMohsin";

            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            statement = connection.createStatement();
            
            //Observe the table and add the list in member List table
            memberTableViewObserb = FXCollections.observableArrayList();
            memberTableView.setItems(memberTableViewObserb);
            
            memberNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            memberNoColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getId()));
            memberPhoneColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getPhone()));
            memberEmailColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getEmail()));
            memberJobColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getJob()));
            memberAddressColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getAddress()));
            memberOtherColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getOther()));
           
            
            String memberQuery = "select * from member";
            ResultSet memberResult = statement.executeQuery(memberQuery);
            
            //Observe the member and add the bazar, extra bazar and depositor in Combo
            memberBazarComboBoxObserve = FXCollections.observableArrayList();
            memberBazarComboBox.setItems(memberBazarComboBoxObserve);
            
            memberExtraBazarComboBoxObserve = FXCollections.observableArrayList();
            memberExtraBazarComboBox.setItems(memberExtraBazarComboBoxObserve);
            
            moneyDepositorComboBoxObserve = FXCollections.observableArrayList();
            moneyDepositorComboBox.setItems(moneyDepositorComboBoxObserve);
            
            mealarRegComboBoxObserve = FXCollections.observableArrayList();
            mealarRegComboBox.setItems(mealarRegComboBoxObserve);
            
            mealDayComboBoxObserve = FXCollections.observableArrayList();
            mealDayComboBox.setItems(mealDayComboBoxObserve);
            
            while(memberResult.next()) {
                String name = memberResult.getString("name");
                int id = memberResult.getInt("id");
                String phone = memberResult.getString("phone");
                String email = memberResult.getString("email");
                String job = memberResult.getString("job");
                String address = memberResult.getString("address");
                String other = memberResult.getString("other");
                
                Member newMember = new Member(id, name, phone, email, job, address, other);
                memberTableViewObserb.add(newMember);
                memberBazarComboBoxObserve.add(name);
                memberExtraBazarComboBoxObserve.add(name);
                moneyDepositorComboBoxObserve.add(name);
                mealarRegComboBoxObserve.add(name);
            }
            //adding day on day combobox
            for (int i=1; i<=31; i++) {
                int day = i;
                
                mealDayComboBoxObserve.add(day);
            }
            
            //Observe the table and add the list in bazar List table
            bazarTableViewObserv = FXCollections.observableArrayList();
            bazarTableView.setItems(bazarTableViewObserv);
            
            bazarDateColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getDate()));
            bazarNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            bazarNoColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getId()));
            bazarAmountColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getAmount()));
            bazarMenuColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getBazar_menu()));
            
            String bazarQuery = "select * from bazar";
            ResultSet bazarResult = statement.executeQuery(bazarQuery);
            
            while(bazarResult.next()) {
                String date = bazarResult.getString("date");
                String name = bazarResult.getString("name");
                int amount = bazarResult.getInt("amount");
                int id = bazarResult.getInt("id");
                String bazar_menu = bazarResult.getString("bazar_menu");
                
                Bazar newBazar = new Bazar(id, date, name, amount, bazar_menu);
                bazarTableViewObserv.add(newBazar);
            }
            
            //Observe the table and add the list in extra bazar List table
            extraBazarTableViewObserv = FXCollections.observableArrayList();
            extraBazarTableView.setItems(extraBazarTableViewObserv);
            
            extrabazarDateColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getDate()));
            extrabazarNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            extrabazarNoColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getId()));
            extrabazarAmountColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getAmount()));
            extrabazarMenuColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getBazar_menu()));
            
            String extrabazarQuery = "select * from extra_bazar";
            ResultSet extrabazarResult = statement.executeQuery(extrabazarQuery);
            
            while(extrabazarResult.next()) {
                String date = extrabazarResult.getString("date");
                String name = extrabazarResult.getString("name");
                int amount = extrabazarResult.getInt("amount");
                String bazar_menu = extrabazarResult.getString("bazar_menu");
                int id = extrabazarResult.getInt("id");
                
                ExtraBazar newextraBazar = new ExtraBazar(id,date, name, amount, bazar_menu);
                extraBazarTableViewObserv.add(newextraBazar);
            }
            
            //Observe the table and add the list in depositor List table
            moneyDepositTableViewObserv = FXCollections.observableArrayList();
            moneyDepositTableView.setItems(moneyDepositTableViewObserv);
            
            moneyDepositNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            moneyDepositDateColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getDate()));
            moneyDepositAmountColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getAmount()));
            moneyDepositNoColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getId()));
            
            String depositorQuery = "select * from depositor";
            ResultSet depositorQueryResult = statement.executeQuery(depositorQuery);
            
            while(depositorQueryResult.next()) {
                String date = depositorQueryResult.getString("date");
                String name = depositorQueryResult.getString("name");
                int amount = depositorQueryResult.getInt("amount");
                int id = depositorQueryResult.getInt("id");
                
                Depositor newDepositor = new Depositor(id, date, name, amount);
                moneyDepositTableViewObserv.add(newDepositor);
            }
            
            //Observe the table and add the list in bazar List table
            mealChartTableViewObserv = FXCollections.observableArrayList();
            mealChartTableView.setItems(mealChartTableViewObserv);
            
            mealarNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            mealDay1.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay1()));
            mealDay2.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay2()));
            mealDay3.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay3()));
            mealDay4.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay4()));
            mealDay5.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay5()));
            mealDay6.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay6()));
            mealDay7.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay7()));
            mealDay8.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay8()));
            mealDay9.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay9()));
            mealDay10.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay10()));
            mealDay11.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay11()));
            mealDay12.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay12()));
            mealDay13.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay13()));
            mealDay14.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay14()));
            mealDay15.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay15()));
            mealDay16.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay16()));
            mealDay17.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay17()));
            mealDay18.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay18()));
            mealDay19.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay19()));
            mealDay20.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay20()));
            mealDay21.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay21()));
            mealDay22.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay22()));
            mealDay23.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay23()));
            mealDay24.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay24()));
            mealDay25.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay25()));
            mealDay26.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay26()));
            mealDay27.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay27()));
            mealDay28.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay28()));
            mealDay29.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay29()));
            mealDay30.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay30()));
            mealDay31.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay31()));
            
            String mealQuery = "select * from meal_chart";
            ResultSet mealQueryResult = statement.executeQuery(mealQuery);
            
            while(mealQueryResult.next()) {
                String name = mealQueryResult.getString("name");
                double day1 = mealQueryResult.getDouble("day1");
                double day2 = mealQueryResult.getDouble("day2");
                double day3 = mealQueryResult.getDouble("day3");
                double day4 = mealQueryResult.getDouble("day4");
                double day5 = mealQueryResult.getDouble("day5");
                double day6 = mealQueryResult.getDouble("day6");
                double day7 = mealQueryResult.getDouble("day7");
                double day8 = mealQueryResult.getDouble("day8");
                double day9 = mealQueryResult.getDouble("day9");
                double day10 = mealQueryResult.getDouble("day10");
                double day11 = mealQueryResult.getDouble("day11");
                double day12 = mealQueryResult.getDouble("day12");
                double day13 = mealQueryResult.getDouble("day13");
                double day14 = mealQueryResult.getDouble("day14");
                double day15 = mealQueryResult.getDouble("day15");
                double day16 = mealQueryResult.getDouble("day16");
                double day17 = mealQueryResult.getDouble("day17");
                double day18 = mealQueryResult.getDouble("day18");
                double day19 = mealQueryResult.getDouble("day19");
                double day20 = mealQueryResult.getDouble("day20");
                double day21 = mealQueryResult.getDouble("day21");
                double day22 = mealQueryResult.getDouble("day22");
                double day23 = mealQueryResult.getDouble("day23");
                double day24 = mealQueryResult.getDouble("day24");
                double day25 = mealQueryResult.getDouble("day25");
                double day26 = mealQueryResult.getDouble("day26");
                double day27 = mealQueryResult.getDouble("day27");
                double day28 = mealQueryResult.getDouble("day28");
                double day29 = mealQueryResult.getDouble("day29");
                double day30 = mealQueryResult.getDouble("day30");
                double day31 = mealQueryResult.getDouble("day31");
                
                MealChart newMeal = new MealChart(name,  day1,  day2,  day3,  day4, day5, day6,  day7,  day8,  day9, day10,  day11, day12, day13, day14,  day15, day16, day17, day18,day19,day20, day21,  day22,day23, day24, day25, day26, day27, day28,day29,day30,day31);
                mealChartTableViewObserv.add(newMeal);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    
    //update member action
    
    @FXML
    private void handleUpdateMemberButton(ActionEvent event) {
        int index = memberTableView.getSelectionModel().getSelectedIndex();
        TablePosition cell = memberTableView.getSelectionModel().getSelectedCells().get(0);
        int row = cell.getRow();
        String idd = memberTableView.getId();
        int id = memberTableView.getItems().get(row).getId();
        try {
            String name = memberNameField.getText();
            String phone = memberPhoneField.getText();
            String email = memberEmailField.getText();
            String job = memberJobField.getText();
            String address = memberAddressField.getText();
            String other = memberOtherField.getText();
            
            String updateMemberQuery = "update member set name='"+name+"', phone='"+phone+"', email='"+email+"', job='"+job+"', address='"+address+"', other='"+other+"' where id='"+id+"';";
            statement.executeUpdate(updateMemberQuery);
            addupdelSuccessLable.setText("Successfully updated.");
            memberTableViewObserb.remove(row);
            
            Member newMember = new Member(id, name, phone, email, job, address, other);
            memberTableViewObserb.add(newMember);
            
            memberNameField.setText("");
            memberPhoneField.setText("");
            memberEmailField.setText("");
            memberJobField.setText("");
            memberAddressField.setText("");
            memberOtherField.setText("");
            
        } catch (SQLException ex) {
            addupdelSuccessLable.setText("Could not update member!");
        }
    }

    @FXML
    private void handleAddMemberButton(ActionEvent event) {
        try {
            String name = memberNameField.getText();
            String phone = memberPhoneField.getText();
            String email = memberEmailField.getText();
            String job = memberJobField.getText();
            String address = memberAddressField.getText();
            String other = memberOtherField.getText();
            int defaultamount = 0 ;
            int id = 0;
            double q = 0;
            
            //adding member
            String addEmployeeQuery = "insert into member(name, phone, email, job, address, other, deposit) values('"+name+"','"+phone+"', '"+email+"' ,'"+job+"' , '"+address+"', '"+other+"', "+defaultamount+");";
            statement.executeUpdate(addEmployeeQuery);
            
            //adding member to meal chart
            String addMealQuery = "insert into meal_chart(name, day1, day2, day3, day4, day5, day6, day7, day8, day9, day10, day11, day12, day13, day14, day15, day16, day17, day18, day19, day20, day21, day22, day23, day24, day25, day26, day27, day28, day29, day30, day31) values('"+name+"',"+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+","+q+");";
            statement.executeUpdate(addMealQuery);
            addupdelSuccessLable.setText("Successfully added.");
            
            //member meal money calculation 
            String addMemCalcuQuery = "insert into calculation(name, total_taka, total_meal) values('"+name+"', "+defaultamount+", "+defaultamount+");";
            statement.executeUpdate(addMemCalcuQuery);
            
            Member newMember = new Member(id, name, phone, email, job, address, other);
            memberTableViewObserb.add(newMember);
            
            memberNameField.setText("");
            memberPhoneField.setText("");
            memberEmailField.setText("");
            memberJobField.setText("");
            memberAddressField.setText("");
            memberOtherField.setText("");
            
        } catch (SQLException ex) {
            addupdelSuccessLable.setText("Could not add member!");
        }
    }

    @FXML
    private void handleDeleteMemberButton(ActionEvent event) {
            Stage confirmStage = new Stage();
            Button okButton = new Button("Ok");
            confirmStage.initModality(Modality.WINDOW_MODAL);
            confirmStage.setHeight(250);
            confirmStage.setWidth(550);
            confirmStage.showAndWait();
            
            okButton.setOnAction(new EventHandler<ActionEvent>(){

                @Override
                public void handle(ActionEvent event) {
                    try {
                        int index = memberTableView.getSelectionModel().getSelectedIndex();
                        TablePosition cell = memberTableView.getSelectionModel().getSelectedCells().get(0);
                        int row = cell.getRow();
                        String name = memberNameField.getText();

                        String deleteMemberQuery = "delete from member where name='"+name+"';";
                        statement.executeUpdate(deleteMemberQuery);
                        addupdelSuccessLable.setText("Successfully delete member.");
                        memberTableViewObserb.remove(row);

                        memberNameField.setText("");
                        memberPhoneField.setText("");
                        memberEmailField.setText("");
                        memberJobField.setText("");
                        memberAddressField.setText("");
                        memberOtherField.setText("");
                    } catch (SQLException ex) {
                        addupdelSuccessLable.setText("Could not delete member!");
                    }
                }
            });
    }
    
    @FXML
    private void memberTableMouseEvent(MouseEvent event) {
        TablePosition cell = memberTableView.getSelectionModel().getSelectedCells().get(0);
        int row = cell.getRow();
        
        String nameEdit = memberTableView.getItems().get(row).getName();
        String phoneEdit = memberTableView.getItems().get(row).getPhone();
        String emailEdit = memberTableView.getItems().get(row).getEmail();
        String jobEdit = memberTableView.getItems().get(row).getJob();
        String addressEdit = memberTableView.getItems().get(row).getAddress();
        String otherEdit = memberTableView.getItems().get(row).getOther();
        
        memberNameField.setText(nameEdit);
        memberPhoneField.setText(phoneEdit);
        memberEmailField.setText(emailEdit);
        memberJobField.setText(jobEdit);
        memberAddressField.setText(addressEdit);
        memberOtherField.setText(otherEdit);
        addupdelSuccessLable.setText("");
    }
    
    @FXML
    private void handleNewMemberButton(ActionEvent event) {
        memberNameField.setText("");
        memberPhoneField.setText("");
        memberEmailField.setText("");
        memberJobField.setText("");
        memberAddressField.setText("");
        memberOtherField.setText("");
        addupdelSuccessLable.setText("");
    }
    
    // bazar action
    @FXML
    private void handleAddBazar(ActionEvent event) {
        try {
            String Date = mainBazardatePicker.getValue().toString();
            String Name = memberBazarComboBox.getSelectionModel().getSelectedItem();
            int quantity = Integer.parseInt(bazarAmountField.getText());
            String bazarMenu = bazarMenuField.getText();
            int id = 0 ;
            
            String BazarQuery = "insert into bazar(date, name, amount, bazar_menu) values ( '"+Date+"', '"+Name+"',  "+quantity+", '"+bazarMenu+"');";
            statement.executeUpdate(BazarQuery);
            
            Bazar newBazar = new Bazar(id, Date, Name, quantity, bazarMenu);
            bazarTableViewObserv.add(newBazar);
            
            memberBazarComboBox.setValue("Choose Member");
            mainBazardatePicker.setValue(LocalDate.now());
            bazarAmountField.setText("");
            bazarMenuField.setText("");
            bazarAddSuccessLabel.setText("");
        } catch (SQLException ex) {
             bazarAddSuccessLabel.setText("Bazar could not added!");
        }
    }
    

    @FXML
    private void handleDeleteMainBazarButton(ActionEvent event) {
        try {
            int index = bazarTableView.getSelectionModel().getSelectedIndex();
            TablePosition cell = bazarTableView.getSelectionModel().getSelectedCells().get(0);
            int row = cell.getRow();
            int id = bazarTableView.getItems().get(row).getId();
            
            String deleteBazarQuery = "delete from bazar where id = "+id+";";
            statement.executeUpdate(deleteBazarQuery);
            addupdelSuccessLable.setText("Successfully updated.");
            bazarTableViewObserv.remove(row);
        } catch (SQLException ex) {
            bazarAddSuccessLabel.setText("Could not delete bazar!");
        }
    }

    @FXML
    private void handleUpdateMainBazarButton(ActionEvent event) {
        int index = bazarTableView.getSelectionModel().getSelectedIndex();
        TablePosition cell = bazarTableView.getSelectionModel().getSelectedCells().get(0);
        int row = cell.getRow();
        int id = bazarTableView.getItems().get(row).getId();
        
        try {
            String name = memberBazarComboBox.getValue();
            String date = mainBazardatePicker.getValue().toString();
            int amount = Integer.parseInt(bazarAmountField.getText());
            String bazar = bazarMenuField.getText();
            
            
            String updateBazarQuery = "update bazar set date='"+date+"', name='"+name+"', amount="+amount+", bazar_menu='"+bazar+"' where id='"+id+"';";
            statement.executeUpdate(updateBazarQuery);
            addupdelSuccessLable.setText("Successfully updated.");
            bazarTableViewObserv.remove(row);
            
            Bazar editBazar = new Bazar(id, date, name, amount, bazar);
            bazarTableViewObserv.add(editBazar);
            
            memberBazarComboBox.setValue("");
            bazarAmountField.setText("");
            bazarMenuField.setText("");
            bazarAddSuccessLabel.setText("");
            
        } catch (SQLException ex) {
            addupdelSuccessLable.setText("Could not add member!");
        }
    }

    @FXML
    private void handleNewMainBazarButton(ActionEvent event) {
            memberBazarComboBox.setValue("Choose Member");
            bazarAmountField.setText("");
            mainBazardatePicker.setValue(LocalDate.now());
            bazarMenuField.setText("");
            bazarAddSuccessLabel.setText("");
    }
    
    @FXML
    private void bazarTableMouseEvent(MouseEvent event) {
        
        TablePosition cell = bazarTableView.getSelectionModel().getSelectedCells().get(0);
        int row = cell.getRow();
        
        String memberEdit = bazarTableView.getItems().get(row).getName();
        String dateEdit = bazarTableView.getItems().get(row).getDate();
        int amountEdit = bazarTableView.getItems().get(row).getAmount();
        String menuEdit = bazarTableView.getItems().get(row).getBazar_menu();
        
        memberBazarComboBox.setValue(memberEdit);
        mainBazardatePicker.setValue(LocalDate.now());
        bazarAmountField.setText(amountEdit + "");
        bazarMenuField.setText(menuEdit);
        bazarAddSuccessLabel.setText("");
    }

    //extra bazar action
    @FXML
    private void handleAddExtraBazar(ActionEvent event) {
        try {
            String Date = extraBazardatePicker.getValue().toString();
            String Name = memberExtraBazarComboBox.getSelectionModel().getSelectedItem();
            int quantity = Integer.parseInt(extraBazarAmountField.getText());
            String bazarMenu = extraBazarMenuField.getText();
            int id = 0;
            
            String extraBazarQuery = "insert into extra_bazar(date, name, amount, bazar_menu) values( '"+Date+"', '"+Name+"',  "+quantity+", '"+bazarMenu+"');";
            statement.executeUpdate(extraBazarQuery);
            
            extrabazarAddSuccessLabel.setText("Extra bazar added!");
            memberExtraBazarComboBox.setValue("Choose Member");
            extraBazarAmountField.setText("");
            extraBazarMenuField.setText("");
            
            ExtraBazar newextraBazar = new ExtraBazar(id, Date, Name, quantity, bazarMenu);
            extraBazarTableViewObserv.add(newextraBazar);
        } catch (SQLException ex) {
             extrabazarAddSuccessLabel.setText("Extra bazar could not added!");
        }
    }

    @FXML
    private void handleDeleteExtraBazarButton(ActionEvent event) {
        try {
            int index = extraBazarTableView.getSelectionModel().getSelectedIndex();
            TablePosition cell = extraBazarTableView.getSelectionModel().getSelectedCells().get(0);
            int row = cell.getRow();
            int id = extraBazarTableView.getItems().get(row).getId();
            
            String deleteBazarQuery = "delete from extra_bazar where id = "+id+";";
            statement.executeUpdate(deleteBazarQuery);
            extrabazarAddSuccessLabel.setText("Successfully deleted.");
            extraBazarTableViewObserv.remove(row);
        } catch (SQLException ex) {
            extrabazarAddSuccessLabel.setText("Could not delete bazar!");
        }
    }

    @FXML
    private void handleUpdateExtraBazarButton(ActionEvent event) {
        try {
            int index = extraBazarTableView.getSelectionModel().getSelectedIndex();
            TablePosition cell = extraBazarTableView.getSelectionModel().getSelectedCells().get(0);
            int row = cell.getRow();
            int id = extraBazarTableView.getItems().get(row).getId();
            
            String name = memberExtraBazarComboBox.getValue();
            String date = extraBazardatePicker.getValue().toString();
            int amount = Integer.parseInt(extraBazarAmountField.getText());
            String bazar = extraBazarMenuField.getText();
            
            
            String updateExtraBazarQuery = "update extra_bazar set date='"+date+"', name='"+name+"', amount="+amount+", bazar_menu='"+bazar+"' where id='"+id+"';";
            statement.executeUpdate(updateExtraBazarQuery);
            extrabazarAddSuccessLabel.setText("Successfully updated.");
            extraBazarTableViewObserv.remove(row);
            
            ExtraBazar updatetBazar = new ExtraBazar(id, date, name, amount, bazar);
            extraBazarTableViewObserv.add(updatetBazar);
            
            memberExtraBazarComboBox.setValue("Choose Member");
            extraBazarAmountField.setText("");
            extraBazarMenuField.setText("");
        } catch (SQLException ex) {
            extrabazarAddSuccessLabel.setText("Extra bazar could not updated!");
        }
    }

    @FXML
    private void handleNewExtraBazarButton(ActionEvent event) {
        memberExtraBazarComboBox.setValue("Choose Member");
        extraBazardatePicker.setValue(LocalDate.now());
        extraBazarAmountField.setText("");
        extraBazarMenuField.setText("");
        extrabazarAddSuccessLabel.setText("");
    }

    @FXML
    private void extrabazarTableMouseEvent(MouseEvent event) {
        TablePosition cell = extraBazarTableView.getSelectionModel().getSelectedCells().get(0);
        int row = cell.getRow();
        
        String memberEdit = extraBazarTableView.getItems().get(row).getName();
        String dateEdit = extraBazarTableView.getItems().get(row).getDate();
        int amountEdit = extraBazarTableView.getItems().get(row).getAmount();
        String menuEdit = extraBazarTableView.getItems().get(row).getBazar_menu();
        
        memberExtraBazarComboBox.setValue(memberEdit);
        extraBazardatePicker.setValue(LocalDate.now());
        extraBazarAmountField.setText(amountEdit + "");
        extraBazarMenuField.setText(menuEdit);
        extrabazarAddSuccessLabel.setText("");
    }

    //deposit action
    @FXML
    private void handleAddDepositMoney(ActionEvent event) {
        int total_taka = 0;
        int final_taka = 0;
        try {
            String Date = datePicker.getValue().toString();
            String depositor = moneyDepositorComboBox.getSelectionModel().getSelectedItem();
            int quantity = Integer.parseInt(moneyDepositAmountField.getText());
            int id =0;
            
            String depositQuery = "insert into depositor(name, amount, date) values( '"+depositor+"', "+quantity+", '"+Date+"');";
            statement.executeUpdate(depositQuery);
            
            Depositor newDepositor = new Depositor(id, Date, depositor, quantity);
            moneyDepositTableViewObserv.add(newDepositor);
            addMoneySuccessLable.setText("Money successfully deposit.");
            
            //getting data from calculation 
            String getcalInfoQuery = "select * from calculation where name = '"+depositor+"';";
            ResultSet getcalInfoQueryResult = statement.executeQuery(getcalInfoQuery);
            
            while(getcalInfoQueryResult.next()) {
                total_taka = getcalInfoQueryResult.getInt("total_taka");
                final_taka = total_taka + quantity;
            }
            
            //update calculation meal and money 
            String updateCalcMemQuery = "update calculation set total_taka="+final_taka+" where name = '"+depositor+"';";
            statement.executeUpdate(updateCalcMemQuery);
            
            moneyDepositAmountField.setText("");
            moneyDepositorComboBox.setValue("Choose Depositor");
            datePicker.setValue(LocalDate.now());
            
        } catch (SQLException ex) {
            addMoneySuccessLable.setText("Something going wrong!");
        }
    }

    @FXML
    private void moneydepositTableMouseEvent(MouseEvent event) {
        TablePosition cell = moneyDepositTableView.getSelectionModel().getSelectedCells().get(0);
        int row = cell.getRow();
        
        String memberEdit = moneyDepositTableView.getItems().get(row).getName();
        String dateEdit = moneyDepositTableView.getItems().get(row).getDate();
        int amountEdit = moneyDepositTableView.getItems().get(row).getAmount();
        
        moneyDepositorComboBox.setValue(memberEdit);
        datePicker.setValue(LocalDate.now());
        moneyDepositAmountField.setText(amountEdit + "");
        addMoneySuccessLable.setText("");
    }
    
    @FXML
    private void handleDeleteDepositButton(ActionEvent event) {
        try {
            int index = moneyDepositTableView.getSelectionModel().getSelectedIndex();
            TablePosition cell = moneyDepositTableView.getSelectionModel().getSelectedCells().get(0);
            int row = cell.getRow();
            int id = moneyDepositTableView.getItems().get(row).getId();
            
            String deleteBazarQuery = "delete from depositor where id = "+id+";";
            statement.executeUpdate(deleteBazarQuery);
            addMoneySuccessLable.setText("Successfully deleted.");
            moneyDepositTableViewObserv.remove(row);
        } catch (SQLException ex) {
            addMoneySuccessLable.setText("Could not delete deposit!");
        }
    }
    
    @FXML
    private void handleUpdateDepositMoneyButton(ActionEvent event) {
        try {
            int index = moneyDepositTableView.getSelectionModel().getSelectedIndex();
            TablePosition cell = moneyDepositTableView.getSelectionModel().getSelectedCells().get(0);
            int row = cell.getRow();
            int id = moneyDepositTableView.getItems().get(row).getId();
        
            String name = moneyDepositorComboBox.getValue();
            String date = datePicker.getValue().toString();
            int amount = Integer.parseInt(moneyDepositAmountField.getText());
            
            
            String updateBazarQuery = "update depositor set date='"+date+"', name='"+name+"', amount="+amount+" where id='"+id+"';";
            statement.executeUpdate(updateBazarQuery);
            addMoneySuccessLable.setText("Successfully updated.");
            moneyDepositTableViewObserv.remove(row);
            
            Depositor editDepositor = new Depositor(id, date, name, amount);
            moneyDepositTableViewObserv.add(editDepositor);
            
            moneyDepositorComboBox.setValue("Choose Depositor");
            moneyDepositAmountField.setText("");
            datePicker.setValue(LocalDate.now());
            
        } catch (SQLException ex) {
            addMoneySuccessLable.setText("Could not deposit!");
        }
    }

    @FXML
    private void handleNewDepositButton(ActionEvent event) {
            moneyDepositorComboBox.setValue("Choose Member");
            moneyDepositAmountField.setText("");
            datePicker.setValue(LocalDate.now());
            addMoneySuccessLable.setText("");
    }

    //logout action
    @FXML
    private void handleLogOutButton(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("MilManagement.fxml"));
            
            Scene scene = new Scene(root);
            
            MilManagement.getStage().setScene(scene);
            MilManagement.getStage().show();
        } catch (IOException ex) {
            Logger.getLogger(MilManagementController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    @FXML
    private void handleAddMealButton(ActionEvent event) {
        //initialize variable
        double total_meal = 0.0;
        double final_meal = 0.0;
        try {
            String Name = mealarRegComboBox.getSelectionModel().getSelectedItem();
            Number day = mealDayComboBox.getSelectionModel().getSelectedItem();
            double amount = Double.parseDouble(mealAmountField.getText());
            if( day.equals(1)){
                String updateAddMealQuery = "update meal_chart set day1= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(2)){
                String updateAddMealQuery = "update meal_chart set day2= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(3)){
                String updateAddMealQuery = "update meal_chart set day3= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(4)){
                String updateAddMealQuery = "update meal_chart set day4= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(5)){
                String updateAddMealQuery = "update meal_chart set day5= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(6)){
                String updateAddMealQuery = "update meal_chart set day6= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(7)){
                String updateAddMealQuery = "update meal_chart set day7= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(8)){
                String updateAddMealQuery = "update meal_chart set day8= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(9)){
                String updateAddMealQuery = "update meal_chart set day9= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(10)){
                String updateAddMealQuery = "update meal_chart set day10= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(11)){
                String updateAddMealQuery = "update meal_chart set day11= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(12)){
                String updateAddMealQuery = "update meal_chart set day12= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(13)){
                String updateAddMealQuery = "update meal_chart set day13= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(14)){
                String updateAddMealQuery = "update meal_chart set day14= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(15)){
                String updateAddMealQuery = "update meal_chart set day15= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(16)){
                String updateAddMealQuery = "update meal_chart set day16= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(17)){
                String updateAddMealQuery = "update meal_chart set day17= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(18)){
                String updateAddMealQuery = "update meal_chart set day18= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(19)){
                String updateAddMealQuery = "update meal_chart set day19= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(20)){
                String updateAddMealQuery = "update meal_chart set day20= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(21)){
                String updateAddMealQuery = "update meal_chart set day21= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(22)){
                String updateAddMealQuery = "update meal_chart set day22= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(23)){
                String updateAddMealQuery = "update meal_chart set day23= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(24)){
                String updateAddMealQuery = "update meal_chart set day24= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(25)){
                String updateAddMealQuery = "update meal_chart set day25= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(26)){
                String updateAddMealQuery = "update meal_chart set day26= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(27)){
                String updateAddMealQuery = "update meal_chart set day27= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(28)){
                String updateAddMealQuery = "update meal_chart set day28= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(29)){
                String updateAddMealQuery = "update meal_chart set day29= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(30)){
                String updateAddMealQuery = "update meal_chart set day30= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }else if( day.equals(31)){
                String updateAddMealQuery = "update meal_chart set day31= "+amount+" where name='"+Name+"';";
                statement.executeUpdate(updateAddMealQuery);
            }
            
            String getcalInfoQuery = "select * from calculation where name = '"+Name+"';";
            ResultSet getcalInfoQueryResult = statement.executeQuery(getcalInfoQuery);
            
            while(getcalInfoQueryResult.next()) {
                total_meal = getcalInfoQueryResult.getDouble("total_meal");
                final_meal = total_meal + amount;
            }
            
            //update calculation meal and money 
            String updateCalcMemQuery = "update calculation set total_meal="+final_meal+" where name = '"+Name+"';";
            statement.executeUpdate(updateCalcMemQuery);
            
            mealarRegComboBox.setValue("Member");
            mealDayComboBox.setValue(day);
            mealAmountField.setText("");
            addMealSuccessLable.setText("Successfully add.");
        } catch (SQLException ex) {
            addMealSuccessLable.setText("Sorry to add");
        }
    }

    @FXML
    private void deleteAllRecordsButton(ActionEvent event) {
        try {
            
            String deleteAllextra_bazarRecordsQuery = "delete from extra_bazar;";
            statement.executeUpdate(deleteAllextra_bazarRecordsQuery);
            
            String deleteAllbazarRecordsQuery = "delete from bazar;";
            statement.executeUpdate(deleteAllbazarRecordsQuery);
            
            String deleteAlldepositorRecordsQuery = "delete from depositor;";
            statement.executeUpdate(deleteAlldepositorRecordsQuery);
            
            String deleteAllmembermemberRecordsQuery = "delete from member;";
            statement.executeUpdate(deleteAllmembermemberRecordsQuery);
            
            String deleteAllmembermeal_chartRecordsQuery = "delete from meal_chart;";
            statement.executeUpdate(deleteAllmembermeal_chartRecordsQuery);
            
            String deleteAllmemberCalculationQuery = "delete from calculation;";
            statement.executeUpdate(deleteAllmemberCalculationQuery);
            
            settingsSuccessLable.setText("Successfully All Record Deleted");
        } catch (SQLException ex) {
            settingsSuccessLable.setText("Record Could not Deleted!!!");
        }
    }
}
