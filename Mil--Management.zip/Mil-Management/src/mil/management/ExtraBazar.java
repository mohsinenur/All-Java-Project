/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.management;

/**
 *
 * @author User
 */
public class ExtraBazar {
    private int id;
    private String date;
    private String name;
    private int amount;
    private String bazar_menu;

    public ExtraBazar(int id, String date, String name, int amount, String bazar_menu) {
        this.id = id;
        this.date = date;
        this.name = name;
        this.amount = amount;
        this.bazar_menu = bazar_menu;
    }

    public String getDate() {
        return date;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAmount() {
        return amount;
    }

    public String getBazar_menu() {
        return bazar_menu;
    }
    
}
