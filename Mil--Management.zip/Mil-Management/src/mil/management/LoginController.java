/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.management;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author User
 */
public class LoginController implements Initializable {
    //variable declearation
    Statement statement;
    @FXML
    private TextField userNameField;
    @FXML
    private Label loginSuccessLable;
    @FXML
    private PasswordField passwordField;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            String DB_URL = "jdbc:mysql://localhost/meal_management_db";
            String DB_USER = "root";
            String DB_PASS = "mysqlMohsin";

            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            statement = connection.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    private void handleLoginButton(ActionEvent event) {
        try {
            String username = userNameField.getText();
            String password = passwordField.getText();
            String query = "select * from manager where username='" + username + "' and password=md5('" + password + "');";
            ResultSet resultSet = statement.executeQuery(query);

            if (resultSet.next()) {

                Parent root = null;

                root = FXMLLoader.load(getClass().getResource("Manager Admin Pannel.fxml"));
                Scene scene = new Scene(root);

                MilManagement.getStage().setScene(scene);
                MilManagement.getStage().show();
            } else {
                loginSuccessLable.setText("Login failed");
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void handleBackButton(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("MilManagement.fxml"));
            
            Scene scene = new Scene(root);
            
            MilManagement.getStage().setScene(scene);
            MilManagement.getStage().show();
        } catch (IOException ex) {
            Logger.getLogger(MilManagementController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void userFieldEnterClickedAction(ActionEvent event) {
        try {
            String username = userNameField.getText();
            String password = passwordField.getText();
            String query = "select * from manager where username='" + username + "' and password=md5('" + password + "');";
            ResultSet resultSet = statement.executeQuery(query);

            if (resultSet.next()) {

                Parent root = null;

                root = FXMLLoader.load(getClass().getResource("Manager Admin Pannel.fxml"));
                Scene scene = new Scene(root);

                MilManagement.getStage().setScene(scene);
                MilManagement.getStage().show();
            } else {
                try {
                    Parent root = FXMLLoader.load(getClass().getResource("MilManagement.fxml"));

                    Scene scene = new Scene(root);

                    MilManagement.getStage().setScene(scene);
                    MilManagement.getStage().show();
                } catch (IOException ex) {
                    Logger.getLogger(MilManagementController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void passFieldEnterClickedAction(ActionEvent event) {
        try {
            String username = userNameField.getText();
            String password = passwordField.getText();
            String query = "select * from manager where username='" + username + "' and password=md5('" + password + "');";
            ResultSet resultSet = statement.executeQuery(query);

            if (resultSet.next()) {

                Parent root = null;

                root = FXMLLoader.load(getClass().getResource("Manager Admin Pannel.fxml"));
                Scene scene = new Scene(root);

                MilManagement.getStage().setScene(scene);
                MilManagement.getStage().show();
            } else {
                try {
                    Parent root = FXMLLoader.load(getClass().getResource("MilManagement.fxml"));

                    Scene scene = new Scene(root);

                    MilManagement.getStage().setScene(scene);
                    MilManagement.getStage().show();
                } catch (IOException ex) {
                    Logger.getLogger(MilManagementController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
}
