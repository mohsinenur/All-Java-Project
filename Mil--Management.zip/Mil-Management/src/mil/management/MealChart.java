/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.management;

/**
 *
 * @author User
 */
public class MealChart {
    private String name;
    private double day1;
    private double day2;
    private double day3;
    private double day4;
    private double day5;
    private double day6;
    private double day7;
    private double day8;
    private double day9;
    private double day10;
    private double day11;
    private double day12;
    private double day13;
    private double day14;
    private double day15;
    private double day16;
    private double day17;
    private double day18;
    private double day19;
    private double day20;
    private double day21;
    private double day22;
    private double day23;
    private double day24;
    private double day25;
    private double day26;
    private double day27;
    private double day28;
    private double day29;
    private double day30;
    private double day31;

    public MealChart(String name, double day1, double day2, double day3, double day4, double day5, double day6, double day7, double day8, double day9, double day10, double day11, double day12, double day13, double day14, double day15, double day16, double day17, double day18, double day19, double day20, double day21, double day22, double day23, double day24, double day25, double day26, double day27, double day28, double day29, double day30, double day31) {
        this.name = name;
        this.day1 = day1;
        this.day2 = day2;
        this.day3 = day3;
        this.day4 = day4;
        this.day5 = day5;
        this.day6 = day6;
        this.day7 = day7;
        this.day8 = day8;
        this.day9 = day9;
        this.day10 = day10;
        this.day11 = day11;
        this.day12 = day12;
        this.day13 = day13;
        this.day14 = day14;
        this.day15 = day15;
        this.day16 = day16;
        this.day17 = day17;
        this.day18 = day18;
        this.day19 = day19;
        this.day20 = day20;
        this.day21 = day21;
        this.day22 = day22;
        this.day23 = day23;
        this.day24 = day24;
        this.day25 = day25;
        this.day26 = day26;
        this.day27 = day27;
        this.day28 = day28;
        this.day29 = day29;
        this.day30 = day30;
        this.day31 = day31;
    }

    public String getName() {
        return name;
    }

    public double getDay1() {
        return day1;
    }

    public double getDay2() {
        return day2;
    }

    public double getDay3() {
        return day3;
    }

    public double getDay4() {
        return day4;
    }

    public double getDay5() {
        return day5;
    }

    public double getDay6() {
        return day6;
    }

    public double getDay7() {
        return day7;
    }

    public double getDay8() {
        return day8;
    }

    public double getDay9() {
        return day9;
    }

    public double getDay10() {
        return day10;
    }

    public double getDay11() {
        return day11;
    }

    public double getDay12() {
        return day12;
    }

    public double getDay13() {
        return day13;
    }

    public double getDay14() {
        return day14;
    }

    public double getDay15() {
        return day15;
    }

    public double getDay16() {
        return day16;
    }

    public double getDay17() {
        return day17;
    }

    public double getDay18() {
        return day18;
    }

    public double getDay19() {
        return day19;
    }

    public double getDay20() {
        return day20;
    }

    public double getDay21() {
        return day21;
    }

    public double getDay22() {
        return day22;
    }

    public double getDay23() {
        return day23;
    }

    public double getDay24() {
        return day24;
    }

    public double getDay25() {
        return day25;
    }

    public double getDay26() {
        return day26;
    }

    public double getDay27() {
        return day27;
    }

    public double getDay28() {
        return day28;
    }

    public double getDay29() {
        return day29;
    }

    public double getDay30() {
        return day30;
    }

    public double getDay31() {
        return day31;
    }
    
}
