/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.management;

import java.awt.Dimension;
import java.awt.Toolkit;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class MilManagement extends Application {
    
    private static Stage loginStage;
    
    public static Stage getStage() {
        return loginStage;
    }
    
    @Override
    public void start(Stage stage) throws Exception {
        //
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        double screenHeight = screenSize.height;
        double screenWidth = screenSize.width;
        loginStage = stage;
        Parent root = FXMLLoader.load(getClass().getResource("MilManagement.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
        stage.setResizable(true);
        //stage.setFullScreen(true);
        stage.setMaxHeight(screenHeight);
        stage.setMaxHeight(screenWidth);
        
        System.out.println(screenHeight);
        System.out.println(screenWidth);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
