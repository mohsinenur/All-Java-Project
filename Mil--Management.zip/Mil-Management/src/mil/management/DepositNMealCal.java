/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.management;

/**
 *
 * @author User
 */
public class DepositNMealCal {
    private String DepositNMealname;
    private int DepositNMealamount;
    private double DepositNMealtotalmeal;
    private int DepositNMealid;
    private double DepositNMealGiveTake;

    public DepositNMealCal(int DepositNMealid,String DepositNMealname ,int DepositNMealamount, double DepositNMealtotalmeal , double DepositNMealGiveTake) {
        this.DepositNMealname = DepositNMealname;
        this.DepositNMealamount = DepositNMealamount;
        this.DepositNMealtotalmeal = DepositNMealtotalmeal;
        this.DepositNMealid = DepositNMealid;
        this.DepositNMealGiveTake = DepositNMealGiveTake;
    }

    public String getDepositNMealname() {
        return DepositNMealname;
    }

    public int getDepositNMealamount() {
        return DepositNMealamount;
    }

    public double getDepositNMealtotalmeal() {
        return DepositNMealtotalmeal;
    }

    public int getDepositNMealid() {
        return DepositNMealid;
    }

    public double getDepositNMealGiveTake() {
        return DepositNMealGiveTake;
    }
    
}
