/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.management;

/**
 *
 * @author User
 */
public class Member {
    private int id;
    private String name;
    private String phone;
    private String email;
    private String job;
    private String address;
    private String other;

    public Member(int id, String name, String phone, String email, String job, String address, String other) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.job = job;
        this.address = address;
        this.other = other;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getJob() {
        return job;
    }

    public String getAddress() {
        return address;
    }

    public String getOther() {
        return other;
    }
}
