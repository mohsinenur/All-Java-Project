/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.management;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author User
 */
public class MilManagementController implements Initializable {
    //variable declearation
    Statement statement;
    
    private Label label;
    @FXML
    private TableView<Member> memberTableView;
    private ObservableList<Member> memberTableViewObserb;
    @FXML
    private TableColumn<Member, Number> memberNoColumn;
    @FXML
    private TableColumn<Member, String> memberNameColumn;
    @FXML
    private TableColumn<Member, String> memberPhoneColumn;
    @FXML
    private TableColumn<Member, String> memberEmailColumn;
    @FXML
    private TableColumn<Member, String> memberJobColumn;
    @FXML
    private TableColumn<Member, String> memberAddressColumn;
    @FXML
    private TableColumn<Member, String> memberOtherColumn;
    @FXML
    private TableView<Bazar> BazarTableView;
    private ObservableList<Bazar> bazarTableViewObserv;
    @FXML
    private TableColumn<Bazar, Number> bazarNoColumn;
    @FXML
    private TableColumn<Bazar, String> bazarDateColumn;
    @FXML
    private TableColumn<Bazar, String> bazarNameColumn;
    @FXML
    private TableColumn<Bazar, Number> bazarAmountColumn;
    @FXML
    private TableColumn<Bazar, String> bazarMenuColumn;
    @FXML
    private TableView<ExtraBazar> extraBazarTableView;
    private ObservableList<ExtraBazar> extraBazarTableViewObserv;
    @FXML
    private TableColumn<ExtraBazar, Number> extrabazarNoColumn;
    @FXML
    private TableColumn<ExtraBazar, String> extrabazarDateColumn;
    @FXML
    private TableColumn<ExtraBazar, String> extrabazarNameColumn;
    @FXML
    private TableColumn<ExtraBazar, Number> extrabazarAmountColumn;
    @FXML
    private TableColumn<ExtraBazar, String> extrabazarMenuColumn;
    @FXML
    private Label totalDepositField;
    @FXML
    private Label totalBazarField;
    @FXML
    private Label totalExtraField;
    @FXML
    private Label totalMealField;
    @FXML
    private Label mealRateField;
    @FXML
    private Label extraRateField;
    
    //declearing some value
    int totalDeposit;
    int totalBazar;
    double totalMeal;
    int totalExtra;
    double extraRate;
    double mealRate;
    int totalMember = 0;
    @FXML
    private Label totalMemberField;
    @FXML
    private TableView<MealChart> mealChartTableView;
    private ObservableList<MealChart> mealChartTableViewObserv;
    @FXML
    private TableColumn<MealChart, String> mealarNameColumn;
    @FXML
    private TableColumn<MealChart, Number> mealDay1;
    @FXML
    private TableColumn<MealChart, Number> mealDay2;
    @FXML
    private TableColumn<MealChart, Number> mealDay3;
    @FXML
    private TableColumn<MealChart, Number> mealDay4;
    @FXML
    private TableColumn<MealChart, Number> mealDay5;
    @FXML
    private TableColumn<MealChart, Number> mealDay6;
    @FXML
    private TableColumn<MealChart, Number> mealDay7;
    @FXML
    private TableColumn<MealChart, Number> mealDay8;
    @FXML
    private TableColumn<MealChart, Number> mealDay9;
    @FXML
    private TableColumn<MealChart, Number> mealDay10;
    @FXML
    private TableColumn<MealChart, Number> mealDay11;
    @FXML
    private TableColumn<MealChart, Number> mealDay12;
    @FXML
    private TableColumn<MealChart, Number> mealDay13;
    @FXML
    private TableColumn<MealChart, Number> mealDay14;
    @FXML
    private TableColumn<MealChart, Number> mealDay15;
    @FXML
    private TableColumn<MealChart, Number> mealDay16;
    @FXML
    private TableColumn<MealChart, Number> mealDay17;
    @FXML
    private TableColumn<MealChart, Number> mealDay18;
    @FXML
    private TableColumn<MealChart, Number> mealDay19;
    @FXML
    private TableColumn<MealChart, Number> mealDay20;
    @FXML
    private TableColumn<MealChart, Number> mealDay21;
    @FXML
    private TableColumn<MealChart, Number> mealDay22;
    @FXML
    private TableColumn<MealChart, Number> mealDay23;
    @FXML
    private TableColumn<MealChart, Number> mealDay24;
    @FXML
    private TableColumn<MealChart, Number> mealDay25;
    @FXML
    private TableColumn<MealChart, Number> mealDay26;
    @FXML
    private TableColumn<MealChart, Number> mealDay27;
    @FXML
    private TableColumn<MealChart, Number> mealDay28;
    @FXML
    private TableColumn<MealChart, Number> mealDay29;
    @FXML
    private TableColumn<MealChart, Number> mealDay30;
    @FXML
    private TableColumn<MealChart, Number> mealDay31;
    @FXML
    private TableView<DepositNMealCal> moneyNMealCalTableView;
    private ObservableList<DepositNMealCal> moneyNMealCalTableViewObserv;
    @FXML
    private TableColumn<DepositNMealCal, Number> moneyNMealCalNoColumn;
    @FXML
    private TableColumn<DepositNMealCal, String> moneyNMealCalNameColumn;
    @FXML
    private TableColumn<DepositNMealCal, Number> moneyNMealCalAmountColumn;
    @FXML
    private TableColumn<DepositNMealCal, Number> moneyNMealCaltotalMealColumn;
    @FXML
    private TableColumn<DepositNMealCal, Number> moneyNMealCaGiveTakeColumn;
    @FXML
    private Label remainingMoneyField;
    @FXML
    private TableColumn<?, ?> totalNMealCaGiveTakeColumn;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            String DB_URL = "jdbc:mysql://localhost/meal_management_db";
            String DB_USER = "root";
            String DB_PASS = "mysqlMohsin";

            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            statement = connection.createStatement();
            //Observe the table and add the list in bazar List table
            mealChartTableViewObserv = FXCollections.observableArrayList();
            mealChartTableView.setItems(mealChartTableViewObserv);
            
            mealarNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            mealDay1.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay1()));
            mealDay2.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay2()));
            mealDay3.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay3()));
            mealDay4.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay4()));
            mealDay5.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay5()));
            mealDay6.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay6()));
            mealDay7.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay7()));
            mealDay8.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay8()));
            mealDay9.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay9()));
            mealDay10.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay10()));
            mealDay11.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay11()));
            mealDay12.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay12()));
            mealDay13.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay13()));
            mealDay14.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay14()));
            mealDay15.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay15()));
            mealDay16.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay16()));
            mealDay17.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay17()));
            mealDay18.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay18()));
            mealDay19.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay19()));
            mealDay20.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay20()));
            mealDay21.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay21()));
            mealDay22.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay22()));
            mealDay23.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay23()));
            mealDay24.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay24()));
            mealDay25.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay25()));
            mealDay26.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay26()));
            mealDay27.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay27()));
            mealDay28.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay28()));
            mealDay29.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay29()));
            mealDay30.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay30()));
            mealDay31.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDay31()));
            
            String mealQuery = "select * from meal_chart";
            ResultSet mealQueryResult = statement.executeQuery(mealQuery);
            
            while(mealQueryResult.next()) {
                String name = mealQueryResult.getString("name");
                double day1 = mealQueryResult.getDouble("day1");
                double day2 = mealQueryResult.getDouble("day2");
                double day3 = mealQueryResult.getDouble("day3");
                double day4 = mealQueryResult.getDouble("day4");
                double day5 = mealQueryResult.getDouble("day5");
                double day6 = mealQueryResult.getDouble("day6");
                double day7 = mealQueryResult.getDouble("day7");
                double day8 = mealQueryResult.getDouble("day8");
                double day9 = mealQueryResult.getDouble("day9");
                double day10 = mealQueryResult.getDouble("day10");
                double day11 = mealQueryResult.getDouble("day11");
                double day12 = mealQueryResult.getDouble("day12");
                double day13 = mealQueryResult.getDouble("day13");
                double day14 = mealQueryResult.getDouble("day14");
                double day15 = mealQueryResult.getDouble("day15");
                double day16 = mealQueryResult.getDouble("day16");
                double day17 = mealQueryResult.getDouble("day17");
                double day18 = mealQueryResult.getDouble("day18");
                double day19 = mealQueryResult.getDouble("day19");
                double day20 = mealQueryResult.getDouble("day20");
                double day21 = mealQueryResult.getDouble("day21");
                double day22 = mealQueryResult.getDouble("day22");
                double day23 = mealQueryResult.getDouble("day23");
                double day24 = mealQueryResult.getDouble("day24");
                double day25 = mealQueryResult.getDouble("day25");
                double day26 = mealQueryResult.getDouble("day26");
                double day27 = mealQueryResult.getDouble("day27");
                double day28 = mealQueryResult.getDouble("day28");
                double day29 = mealQueryResult.getDouble("day29");
                double day30 = mealQueryResult.getDouble("day30");
                double day31 = mealQueryResult.getDouble("day31");
                
                MealChart newMeal = new MealChart(name,  day1,  day2,  day3,  day4, day5, day6,  day7,  day8,  day9, day10,  day11, day12, day13, day14,  day15, day16, day17, day18,day19,day20, day21,  day22,day23, day24, day25, day26, day27, day28,day29,day30,day31);
                mealChartTableViewObserv.add(newMeal);
                totalMeal += (day1 + day2 + day3+  day4+ day5+ day6+  day7+  day8+  day9+ day10+  day11+ day12+ day13+ day14+  day15+ day16+ day17+ day18+day19+day20+ day21+  day22+day23+ day24+ day25+ day26+ day27+ day28+day29+day30+day31);
            }
            
            //Observe the table and add the list in member List table
            memberTableViewObserb = FXCollections.observableArrayList();
            memberTableView.setItems(memberTableViewObserb);
            
            memberNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            memberNoColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getId()));
            memberPhoneColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getPhone()));
            memberEmailColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getEmail()));
            memberJobColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getJob()));
            memberAddressColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getAddress()));
            memberOtherColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getOther()));
            
            
            String memberQuery = "select * from member";
            ResultSet memberResult = statement.executeQuery(memberQuery);
            int member = 1;
            while(memberResult.next()) {
                String name = memberResult.getString("name");
                int id = memberResult.getInt("id");
                String phone = memberResult.getString("phone");
                String email = memberResult.getString("email");
                String job = memberResult.getString("job");
                String address = memberResult.getString("address");
                String other = memberResult.getString("other");
                
                Member newMember = new Member(id, name, phone, email, job, address, other);
                memberTableViewObserb.add(newMember);
                
                totalMember += member;
            }   
            //Observe the table and add the list in bazar List table
            bazarTableViewObserv = FXCollections.observableArrayList();
            BazarTableView.setItems(bazarTableViewObserv);
            
            bazarDateColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getDate()));
            bazarNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            bazarNoColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getId()));
            bazarAmountColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getAmount()));
            bazarMenuColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getBazar_menu()));
            
            String bazarQuery = "select * from bazar";
            ResultSet bazarResult = statement.executeQuery(bazarQuery);
            
            while(bazarResult.next()) {
                String date = bazarResult.getString("date");
                String bname = bazarResult.getString("name");
                int amount = bazarResult.getInt("amount");
                int bid = bazarResult.getInt("id");
                String bazar_menu = bazarResult.getString("bazar_menu");
                
                Bazar newBazar = new Bazar(bid, date, bname, amount, bazar_menu);
                bazarTableViewObserv.add(newBazar);
                totalBazar += amount;
            }
            
            //Observe the table and add the list in extra bazar List table
            extraBazarTableViewObserv = FXCollections.observableArrayList();
            extraBazarTableView.setItems(extraBazarTableViewObserv);
            
            extrabazarDateColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getDate()));
            extrabazarNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            extrabazarNoColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getId()));
            extrabazarAmountColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getAmount()));
            extrabazarMenuColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getBazar_menu()));
            
            String extrabazarQuery = "select * from extra_bazar";
            ResultSet extrabazarResult = statement.executeQuery(extrabazarQuery);
            
            while(extrabazarResult.next()) {
                String date = extrabazarResult.getString("date");
                String ebname = extrabazarResult.getString("name");
                int amount = extrabazarResult.getInt("amount");
                String bazar_menu = extrabazarResult.getString("bazar_menu");
                int ebid = extrabazarResult.getInt("id");
                
                ExtraBazar newextraBazar = new ExtraBazar(ebid, date, ebname, amount, bazar_menu);
                extraBazarTableViewObserv.add(newextraBazar);
                totalExtra += amount;
            }
            //Observe the table and add the list in calculation List table
            moneyNMealCalTableViewObserv = FXCollections.observableArrayList();
            moneyNMealCalTableView.setItems(moneyNMealCalTableViewObserv);
            
            moneyNMealCalNoColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getDepositNMealid()));
            moneyNMealCalNameColumn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getDepositNMealname()));
            moneyNMealCalAmountColumn.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getDepositNMealamount()));
            moneyNMealCaltotalMealColumn.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDepositNMealtotalmeal()));
            moneyNMealCaGiveTakeColumn.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getDepositNMealGiveTake()));
            
            
            //Show only two digit after decimal
            DecimalFormat dFormat = new DecimalFormat("#.##");
            
            //All Calculation
                totalDepositField.setText(totalDeposit + "");
                totalExtraField.setText(totalExtra + "");
                totalBazarField.setText(totalBazar + "");
                totalMealField.setText(totalMeal + "");
                totalMemberField.setText(totalMember + "");
                
                //calculating meal rate
                double totalMealRate = 0.0;
                if (totalMember != 0) {
                totalMealRate = totalBazar / totalMeal;
                mealRateField.setText(dFormat.format(totalMealRate));
                
                 double totalExtraRate = totalExtra / totalMember;
                 extraRateField.setText(totalExtraRate + "");
                }else{
                mealRateField.setText(0.0 + "");
                extraRateField.setText(0.0 + "");
                }
                
                //calculating extra rate
              //  extraRateField.setText(totalExtra / totalMember + "");
            
            
            
            String DepositNMealCalQuery = "select * from calculation";
            ResultSet DepositNMealCalQueryResult = statement.executeQuery(DepositNMealCalQuery);
            
            while(DepositNMealCalQueryResult.next()) {
                String DepositNMealname = DepositNMealCalQueryResult.getString("name");
                int DepositNMealamount = DepositNMealCalQueryResult.getInt("total_taka");
                double DepositNMealtotalmeal = DepositNMealCalQueryResult.getDouble("total_meal");
                int DepositNMealid = DepositNMealCalQueryResult.getInt("id");
                
                double DepositNMealGiveTake = DepositNMealamount - (DepositNMealtotalmeal *  totalMealRate);
                
                DepositNMealGiveTake = Double.parseDouble(dFormat.format(DepositNMealGiveTake));
                DepositNMealCal newDepositNMealCal = new DepositNMealCal(DepositNMealid, DepositNMealname, DepositNMealamount, DepositNMealtotalmeal, DepositNMealGiveTake);
                moneyNMealCalTableViewObserv.add(newDepositNMealCal);
                
                totalDeposit += DepositNMealamount;
            }
            
            totalDepositField.setText(totalDeposit + "");
            remainingMoneyField.setText((totalDeposit - totalBazar - totalExtra) + "");
                
        } catch (SQLException ex) {
            Logger.getLogger(MilManagementController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void handleLoginButton(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
            
            Scene scene = new Scene(root);
            
            MilManagement.getStage().setScene(scene);
            MilManagement.getStage().show();
        } catch (IOException ex) {
            Logger.getLogger(MilManagementController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
