/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.management;

import java.time.LocalDate;

/**
 *
 * @author User
 */
    public class Depositor {
    private String name;
    private int amount;
    private int id;
    private String date;

    public Depositor( int id, String date, String name, int amount) {
        this.name = name;
        this.date = date;
        this.amount = amount;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getAmount() {
        return amount;
    }

    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }
    
}
