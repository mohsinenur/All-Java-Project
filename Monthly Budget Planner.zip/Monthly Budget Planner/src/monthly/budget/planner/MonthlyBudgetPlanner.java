/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monthly.budget.planner;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import static monthly.budget.planner.FXMLDocumentController.readFile;

/**
 *
 * @author Asaduzzaman Noor
 */
public class MonthlyBudgetPlanner extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        
        stage.setScene(scene);
       // scene.getStylesheets().add(Monthly Budget Planner//styles.css)
        stage.getIcons().add(new Image("http://www.altfi.com/images/upload/featuredimages/article532featuredimage-1.png"));
        stage.setTitle("Budget Planner");
        stage.setWidth(593);
        stage.setHeight(600);
        stage.setResizable(false);
        
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
        readFile();
    }

    private void toExternalForm() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
