/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monthly.budget.planner;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

/**
 *
 * @author Asaduzzaman Noor
 * 
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label todaysDateLabel;
    @FXML
    private Label monthLabel;
    @FXML
    private TextField transactionAmountField;
    @FXML
    private TextArea transactionDescriptionField;
    @FXML
    private TextField incomeAmountField;
    @FXML
    private TextArea incomeDescriptionField;
    @FXML
    private TextField expenseAmountField;
    @FXML
    private TextArea expenseDescriptionField;
    @FXML
    private TextField categoryNameField;
    @FXML
    private ToggleGroup typesOfCategory;
    @FXML
    private RadioButton radioCategoryIncome;
    @FXML
    private RadioButton radioCategoryExpanse;
    @FXML
    private DatePicker datePicker;
    @FXML
    private Label transactionError;
    @FXML
    private Label incomeError;
    @FXML
    private Label expenseError;
    @FXML
    private Label categoryError;
    @FXML
    private Label totalIncomeField;
    @FXML
    private Label totalExpenseField;
    @FXML
    private Label totalRemainingBalance;
    @FXML
    private Label transactionSuccessLable;
    @FXML
    private ComboBox<String> incomeComboboxCategory;
    ObservableList<String> incomeComboCategory;
    @FXML
    private Label incomeSuccessLable;
    @FXML
    private ComboBox<String> expenseComboboxCategory;
    ObservableList<String> expenseComboCategory;
    @FXML
    private Label expenseSuccessLable;
    @FXML
    private Label categorySuccessLable;
    String categoryType;
    String categoryName;
    String expenseComboboxCategorys;   
    String incomeComboboxCategorys;    
    String transactionCategoryComboboxs;    
    String incomeTransComboboxCategorys;    
    String expenseTransComboboxCategorys;    
    @FXML
    private ComboBox<String> expenseTransComboboxCategory;
    ObservableList<String> expenseTransComboCategory;
    @FXML
    private ListView<String> incomeListViewField;       
    ObservableList<String> incomeList;
    @FXML
    private ListView<String> expenseListViewField;
    ObservableList<String> expenseList;
    @FXML
    private ListView<String> transactionHistoryListview;
    ObservableList<String> transactionHistory;
    @FXML
    private Label expenseBudgetLabel;
    @FXML
    private Label expenseBudgetTotal;
    @FXML
    private Label expenseBudgetRemeining;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Add Todays Date when opened application
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        Date date = new Date();
        todaysDateLabel.setText(dateFormat.format(date));
        
        LocalDate today = LocalDate.now();
        datePicker.setValue(today);
        LocalDate DatePicker = datePicker.getValue();  
        Month getMonth = DatePicker.getMonth();
        String month = getMonth + "";  
        int year = DatePicker.getYear();
        
        monthLabel.setText(month + " " + year);
        
        
        //Add income category
        incomeComboCategory = FXCollections.observableArrayList();
        incomeComboboxCategory.setItems(incomeComboCategory);
        
        //Add expense category
        expenseComboCategory = FXCollections.observableArrayList();
        expenseComboboxCategory.setItems(expenseComboCategory);
        
        //Add trans expense category
        expenseTransComboCategory = FXCollections.observableArrayList();
        expenseTransComboboxCategory.setItems(expenseTransComboCategory);
        
        //Show Income List 
        incomeList = FXCollections.observableArrayList();
        incomeListViewField.setItems(incomeList);
        
        //Show Expense List 
        expenseList = FXCollections.observableArrayList();
        expenseListViewField.setItems(expenseList);
        
        //Show Transaction List 
        transactionHistory = FXCollections.observableArrayList();
        transactionHistoryListview.setItems(transactionHistory);
        
    }    
    
    //Select Month and Date from DatePicker and showed on Summery MonthLabel
    @FXML
    private void handleCalender(ActionEvent event) { 
        LocalDate DatePicker = datePicker.getValue();
        
       // LocalDate today = LocalDate.now();
       // datePicker.setValue(today);
        
        Month getMonth = DatePicker.getMonth();
        String month = getMonth + "";  
        int year = DatePicker.getYear();
        
        monthLabel.setText(month + " " + year);
        
    }
    
    
    public static void readFile() {
        RandomAccessFile input;
        try {
            input = new RandomAccessFile("income.txt", "r");
            String line;
//            while ((line = input.readLine()) != null)
            while (true) {
                line = input.readLine();
                if (line == null)
                    break;
                System.out.printf("%s\n", line);
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    @FXML
    private void handleIncomeComboboxCategory(ActionEvent event) {
        incomeComboboxCategorys = incomeComboboxCategory.getSelectionModel().getSelectedItem();
    }
    
    @FXML
    private void handleExpenseComboboxCategory(ActionEvent event) {
        expenseComboboxCategorys = expenseComboboxCategory.getSelectionModel().getSelectedItem();
    }

    @FXML
    private void handleExpenseTransComboboxCategory(ActionEvent event) {
        expenseTransComboboxCategorys = expenseTransComboboxCategory.getSelectionModel().getSelectedItem();
    }

    @FXML
    private void handleIncomeAddButton(ActionEvent event) {
        try {
            //checking input fields
            if (incomeComboboxCategory.getSelectionModel().getSelectedItem() == null){
                incomeError.setText("Select category!");
                incomeSuccessLable.setText("");
            }else if (incomeAmountField.getText().equals("")) {
                incomeError.setText("Input amount!");
                incomeSuccessLable.setText("");
            }else if (incomeDescriptionField.getText().equals("")) {
                incomeError.setText("Write description!");
                incomeSuccessLable.setText("");
            }else {
            LocalDate incomeDate = datePicker.getValue();
            Double incomeAmount = Double.parseDouble(incomeAmountField.getText()) ;
            String incomeDescription = incomeDescriptionField.getText();
            String incomeComboCategorysss = incomeComboboxCategorys;
            //get and write income txt file
            RandomAccessFile output = new RandomAccessFile("income.txt", "rw");
            output.seek(output.length());
            output.writeBytes(incomeDate + "\n");
            output.writeBytes(incomeAmount + "\n");
            output.writeBytes(incomeComboCategorysss + "\n");
            output.writeBytes(incomeDescription + "\n");
            
            //This Section for Showing Category and Amount to the Income ListView
            String addIncomeList =incomeDate + " --- " +incomeComboCategorysss + " --- " + incomeAmount;     //Storing two String to one String
            String transactionHistree = "Income --- " +  incomeDate + " --- " + incomeComboCategorysss + " --- " + incomeAmount + " --- " + incomeDescription;     //Storing two String to one String
            incomeList.add(0,addIncomeList); 
            transactionHistory.add(0,transactionHistree); 
            
            double totalIncomeAmount = Double.parseDouble(totalIncomeField.getText());
            double totalIncome = incomeAmount + totalIncomeAmount;
            totalIncomeField.setText(totalIncome + "");
            double totalExpense = Double.parseDouble(totalExpenseField.getText());
            double totalRemaining = totalIncome - totalExpense;
            totalRemainingBalance.setText(totalRemaining + "");
            incomeAmountField.setText("");
            incomeError.setText("");
            incomeDescriptionField.setText("");
            incomeSuccessLable.setText("Successfully Income Data Added.");
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void handleExpenseAddButton(ActionEvent event) {
            
        try {
            //checking input fields
            if (expenseComboboxCategory.getSelectionModel().getSelectedItem() == null){
                expenseError.setText("Select category!");
                expenseSuccessLable.setText("");
            }else if (expenseAmountField.getText().equals("")) {
                expenseError.setText("Input amount!");
                expenseSuccessLable.setText("");
            }else if (expenseDescriptionField.getText().equals("")) {
                expenseError.setText("Write description!");
                expenseSuccessLable.setText("");
            }else {
                //getting value
                LocalDate expenseDate = datePicker.getValue();
                Double expenseAmount = Double.parseDouble(expenseAmountField.getText()) ;
                String expenseDescription = expenseDescriptionField.getText();
                String expenseComboCategorysss = expenseComboboxCategorys;

                RandomAccessFile expensefile = new RandomAccessFile("expense.txt", "rw");
                expensefile.seek(expensefile.length());
                expensefile.seek(expensefile.length());
                expensefile.seek(expensefile.length());

                expensefile.writeBytes(expenseDate + "\n");
                expensefile.writeBytes(expenseComboCategorysss + "\n");
                expensefile.writeBytes(expenseAmount + "\n");
                expensefile.writeBytes(expenseDescription + "\n");

                //This Section for Showing Category and Amount to the Income ListView
                String addExpenseList = expenseDate + " --- " + expenseComboCategorysss + " --- " + expenseAmount;     //Storing two String to one String
                expenseList.add(0,addExpenseList);
                //total calculation

                double Expense = Double.parseDouble(totalExpenseField.getText()); //summery total expense
                double totalExpenseBudget = Double.parseDouble(expenseBudgetLabel.getText());
                double totalExpenseBudgettt = totalExpenseBudget + expenseAmount;
                double expenseBudgetTotall = Double.parseDouble(expenseBudgetTotal.getText());
                double expenseBudgetRemein= totalExpenseBudgettt - expenseBudgetTotall;

                expenseBudgetLabel.setText(totalExpenseBudgettt + "");
                expenseBudgetTotal.setText(Expense + "");
                expenseBudgetRemeining.setText(expenseBudgetRemein + "");
                expenseError.setText("");
                expenseAmountField.setText("");
                expenseDescriptionField.setText("");
                expenseSuccessLable.setText("Successfully Expense Data Added.");
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
      

    }

    @FXML
    private void handleCategoryTypeRadioIncome() {
        categoryType = "Income";
        categoryName = categoryNameField.getText();
        categoryError.setText("");
        categorySuccessLable.setText("");
    }

    @FXML
    private void handleCategoryTypeRadioExpense() {
        categoryType = "Expense";
        categoryName = categoryNameField.getText();
        categoryError.setText("");
        categorySuccessLable.setText("");
    }
    
    @FXML
    private void handleCategoryAddButton(ActionEvent event) throws FileNotFoundException {
        categoryName = categoryNameField.getText();
        if(radioCategoryIncome.isSelected() || radioCategoryExpanse.isSelected())
        {
          if(!categoryName.equals(""))
          {
            switch (categoryType) {
                case "Income":
                    categoryType = "Income";
                    incomeComboCategory.add(0, categoryName);

                    try {
                        RandomAccessFile output = new RandomAccessFile("incomecategory.txt", "rw");
                        output.seek(output.length());
                        output.writeBytes(categoryName + "\n");
                        categoryNameField.setText("");
                        categorySuccessLable.setText("Successfully Income Category Added.");
                        categoryError.setText("");
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;
                    
                case "Expense":
                    categoryType = "Expense";
                    expenseComboCategory.add(0, categoryName);
                    expenseTransComboCategory.add(0, categoryName);
                    try {
                        RandomAccessFile output = new RandomAccessFile("expensecategory.txt", "rw");
                        output.seek(output.length());
                        output.writeBytes(categoryName + "\n");
                        categoryNameField.setText("");
                        categorySuccessLable.setText("Successfully Expense Category Added.");
                        categoryError.setText("");
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;
                default:    
                    break;
                }  
            }
          
            else
            {
                categoryError.setText("Please Enter Category Name");
                categorySuccessLable.setText("");
            }
        }    
        else
        {
            categoryError.setText("Please Enter Category Type");
            categorySuccessLable.setText("");
        }
    }

    @FXML
    private void handleTransactionAddButton(ActionEvent event) {
        try {
            if (expenseTransComboboxCategory.getSelectionModel().getSelectedItem() == null){
                transactionError.setText("Please Select a Category!");
                transactionSuccessLable.setText("");
            }else if (transactionAmountField.getText().equals("")) {
                transactionError.setText("Please input an Amount!");
                transactionSuccessLable.setText("");
            }else if (transactionDescriptionField.getText().equals("")) {
                transactionError.setText("You forgot to write Description!");
                transactionSuccessLable.setText("");
            }else {
                LocalDate transactDate = datePicker.getValue();
                double transactionAmount = Double.parseDouble(transactionAmountField.getText()) ;
                double totalIncomeAmount = Double.parseDouble(totalIncomeField.getText()); //get total income
                String transactionDescription = transactionDescriptionField.getText();
                String transactionComboCategory = expenseTransComboboxCategorys;
            
                RandomAccessFile output = new RandomAccessFile("transaction.txt", "rw");
                output.seek(output.length());

                output.writeBytes(transactionComboCategory + "\n");
                output.writeBytes(transactionAmount + "\n");
                output.writeBytes(transactionDescription + "\n");

                String transactionHistree = "Expense --- " + transactDate + " --- " + transactionComboCategory + " --- " + transactionAmount + " --- " + transactionDescription;     //Storing two String to one String
                transactionHistory.add(0,transactionHistree);

                double Expense = Double.parseDouble(totalExpenseField.getText()); // get total expense
                double expenseBudgetLab= Double.parseDouble(expenseBudgetLabel.getText()); //get expense budget 
                double totalExpense = Expense + transactionAmount;
                expenseBudgetTotal.setText(totalExpense + "");
                double totalRemaining = totalIncomeAmount - totalExpense;
                double totalRemainingBudget = expenseBudgetLab - totalExpense;
                totalExpenseField.setText(totalExpense + "");
                totalRemainingBalance.setText(totalRemaining + "");
                expenseBudgetRemeining.setText(totalRemainingBudget + "");
                transactionAmountField.setText("");
                transactionDescriptionField.setText("");
                if (totalIncomeAmount < transactionAmount) {
                transactionError.setText("Successfull! But remeining balance goes negative.");
                transactionSuccessLable.setText("");
                }else {
                    transactionSuccessLable.setText("Transaction Successfull.");
                    transactionError.setText("");
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void handleTransactionMenubar(Event event) {
        transactionSuccessLable.setText("");
        transactionError.setText("");
        incomeSuccessLable.setText("");
        incomeError.setText("");
        expenseSuccessLable.setText("");
        expenseError.setText("");
        categoryError.setText("");
        categorySuccessLable.setText("");
    }

    @FXML
    private void handleIncomeMenubar(Event event) {
        transactionSuccessLable.setText("");
        transactionError.setText("");
        incomeSuccessLable.setText("");
        incomeError.setText("");
        expenseSuccessLable.setText("");
        expenseError.setText("");
        categoryError.setText("");
        categorySuccessLable.setText("");
    }

    @FXML
    private void handleExpenseMenubar(Event event) {
        transactionSuccessLable.setText("");
        transactionError.setText("");
        incomeSuccessLable.setText("");
        incomeError.setText("");
        expenseSuccessLable.setText("");
        expenseError.setText("");
        categoryError.setText("");
        categorySuccessLable.setText("");
    }

    @FXML
    private void handleCategoryMenubar(Event event) {
        transactionSuccessLable.setText("");
        transactionError.setText("");
        incomeSuccessLable.setText("");
        incomeError.setText("");
        expenseSuccessLable.setText("");
        expenseError.setText("");
        categoryError.setText("");
        categorySuccessLable.setText("");
    }


    @FXML
    private void handleTransactinHistMenubar(Event event) {
        transactionSuccessLable.setText("");
        transactionError.setText("");
        incomeSuccessLable.setText("");
        incomeError.setText("");
        expenseSuccessLable.setText("");
        expenseError.setText("");
        categoryError.setText("");
        categorySuccessLable.setText("");
    }

    @FXML
    private void handleChartMenubar(Event event) {
        transactionSuccessLable.setText("");
        transactionError.setText("");
        incomeSuccessLable.setText("");
        incomeError.setText("");
        expenseSuccessLable.setText("");
        expenseError.setText("");
        categoryError.setText("");
        categorySuccessLable.setText("");
    }

    @FXML
    private void handleHelpMenubar(Event event) {
        transactionSuccessLable.setText("");
        transactionError.setText("");
        incomeSuccessLable.setText("");
        incomeError.setText("");
        expenseSuccessLable.setText("");
        expenseError.setText("");
        categoryError.setText("");
        categorySuccessLable.setText("");
    }

    @FXML
    private void handleAboutMenubar(Event event) {
        transactionSuccessLable.setText("");
        transactionError.setText("");
        incomeSuccessLable.setText("");
        incomeError.setText("");
        expenseSuccessLable.setText("");
        expenseError.setText("");
        categoryError.setText("");
        categorySuccessLable.setText("");
    }

    @FXML
    private void handleSummaryMenubar(Event event) {
    }

}
